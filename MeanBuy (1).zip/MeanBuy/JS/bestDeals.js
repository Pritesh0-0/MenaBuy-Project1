var productData = [
  {
    image: "../Images/1.jfif",
    title: "Women Cotton And Linen Bohemian Beach Skirt",
    rating: 1.7,
    price: "1299",
    off: "UP TO 28% OFF",
    des: "This beautifully handcrafted skirt will make u star of summer garden parties. It features elastic belt and made up of good quality. Easy pattern that sits along your body curves and gives that ultra feminine look, this garment is also very comfortable and stays along you body without clingling too much and gives out a good shape. This beautifully handcrafted skirt will make u star of summer garden parties. It features elastic belt and made up of good quality. Easy pattern that sits along your body curves and gives that ultra feminine look, this garment is also very comfortable and stays along you body without clingling too much and gives out a good shape.",
  },
  {
    image: "../Images/2.jfif",
    title: "Handsfree Earphone",
    rating: 3.6,
    price: "3199",
    off: "UP TO 29% OFF",
    des: "Featuring an unique neck-strap and ultra light weight designed specially for easy carrying for all day comfort. The flexible, bendable, neckband style ensures comfortable fit. Easy to operate. You can play, skip and pause music, control volume and pick up calls. Vibration alert on power on and coming calls, and the battery level of these headsets will be displayed on your cellphone. Featuring an unique neck-strap and ultra light weight designed specially for easy carrying for all day comfort. The flexible, bendable, neckband style ensures comfortable fit. Easy to operate. You can play, skip and pause music, control volume and pick up calls. Vibration alert on power on and coming calls, and the battery level of these headsets will be displayed on your cellphone.",
  },
  {
    image: "../Images/3.jfif",
    title: "Langsdom Neckband Bluetooth",
    rating: 2.2,
    price: "2199",
    off: "UP TO 27% OFF",
    des: "Vibration and Voice Prompt Vibration and voice prompt: when there's coming call, this earphone will remind you with vibration. Will never miss any phone call when you are doing exercise or even in a noisy place.Bluetooth 4.1 Technology More energy-efficient, stable, and faster transmission speed. Very low standby power consumption quick pairing.Magnetic Earbuds and Lightweight Neckband design allows for a more snug and comfortable fit around the neck. Magnetic earbuds can prevent tangles in the cords. Noise Reduction Technology DSP noise cancelling technology reduces noise and increases call resolution, which provides you high-quality sound and clearer voice for calls Vibration and Voice Prompt Vibration and voice prompt: when there's coming call, this earphone will remind you with vibration. Will never miss any phone call when you are doing exercise or even in a noisy place.Bluetooth 4.1 Technology More energy-efficient, stable, and faster transmission speed. Very low standby power consumption quick pairing.Magnetic Earbuds and Lightweight Neckband design allows for a more snug and comfortable fit around the neck. Magnetic earbuds can prevent tangles in the cords. Noise Reduction Technology DSP noise cancelling technology reduces noise and increases call resolution, which provides you high-quality sound and clearer voice for calls",
  },
  {
    image: "../Images/4.jfif",
    title: "400ml Electric Squeezer",
    rating: 3.6,
    price: "2899",
    off: "UP TO 28% OFF",
    des: "Brand Name: Sand Dunes, Type: Citrus Juicer, Material:Stainless Steel+Plastic, Housing Material: Stainless Steel, Shape of Charging Port: Round, Capacity:400ml, Power (W): 201-500W, Voltage:AC 220v-240V 50-60 HZ, Speed:80RPM, Color: Gray, Size:about 24cm/9.45x15.5cm, Package Included: 1 x Electric Juicer, 1 x Power- Adapter Brand Name: Sand Dunes, Type: Citrus Juicer, Material:Stainless Steel+Plastic, Housing Material: Stainless Steel, Shape of Charging Port: Round, Capacity:400ml, Power (W): 201-500W, Voltage:AC 220v-240V 50-60 HZ, Speed:80RPM, Color: Gray, Size:about 24cm/9.45x15.5cm, Package Included: 1 x Electric Juicer, 1 x Power- Adapter Brand Name: Sand Dunes, Type: Citrus Juicer, Material:Stainless Steel+Plastic, Housing Material: Stainless Steel, Shape of Charging Port: Round, Capacity:400ml, Power (W): 201-500W, Voltage:AC 220v-240V 50-60 HZ, Speed:80RPM, Color: Gray, Size:about 24cm/9.45x15.5cm, Package Included: 1 x Electric Juicer, 1 x Power- Adapter",
  },
  {
    image: "../Images/5.jfif",
    title: "Mini Amplifier & Subwoofer",
    rating: 5.0,
    price: "1499",
    off: "UP TO 40% OFF",
    des: "This two channel amplifier will fill a room with audio. As a bass reflex design, the Mini Amplifier delivers deep, low bass throughout the entire listening space. It is perfect for rooms without an actual subwoofer or for the budget conscious alike. You don't have to be a DJ to rock out in style with the All In One Mini Amplifier & Subwoofer. Featuring 1100 watt power, built-in stereo speakers, a 90 x 10 watt peak swg swg swg mmmmm.m m m m moom.m m. This two channel amplifier will fill a room with audio. As a bass reflex design, the Mini Amplifier delivers deep, low bass throughout the entire listening space. It is perfect for rooms without an actual subwoofer or for the budget conscious alike. You don't have to be a DJ to rock out in style with the All In One Mini Amplifier & Subwoofer. Featuring 1100 watt power, built-in stereo speakers, a 90 x 10 watt peak swg swg swg mmmmm.m m m m moom.m m.",
  },
  {
    image: "../Images/6.jfif",
    title: "Mens Luxury Mechanical Watch",
    rating: 1.9,
    price: "8999",
    off: "UP TO 40% OFF",
    des: "Luxury Watch Brand Luxury Watch Brand, Watch arrives in white market box with complimentary cleaning cloth. Operating System has automatic complications, and is compatible with Android and Apple Watch. With 100m Water Resistance and an accurate mechanical movement, this watch is built for both classy and rugged. Luxury Watch Brand Luxury Watch Brand, Watch arrives in white market box with complimentary cleaning cloth. Operating System has automatic complications, and is compatible with Android and Apple Watch. With 100m Water Resistance and an accurate mechanical movement, this watch is built for both classy and rugged.",
  },
  {
    image: "../Images/7.jfif",
    title: "Women Versatile Straight Suit",
    rating: 2.7,
    price: "6799",
    off: "UP TO 35% OFF",
    des: "Versatile Straight Suit for women has three adjustable shoulder straps, 10% stretch cotton fabric, and a ruffle trim. Front pockets. Distressed denim on jacket. Introducing Jacqueline by Farrah Gray--a women's care suit that can be dressed up or down, to your liking. This women's suit is made with luxurious fabrics including a gold metallic patterned overlay. This women's suit is made with luxurious fabrics including a gold metallic patterned overlay. Jacqueline by Farrah Gray tapers at hem and is flattering on any shape. Versatile Straight Suit for women has three adjustable shoulder straps, 10% stretch cotton fabric, and a ruffle trim. Front pockets. Distressed denim on jacket. Introducing Jacqueline by Farrah Gray--a women's care suit that can be dressed up or down, to your liking. This women's suit is made with luxurious fabrics including a gold metallic patterned overlay. This women's suit is made with luxurious fabrics including a gold metallic patterned overlay. Jacqueline by Farrah Gray tapers at hem and is flattering on any shape.",
  },
  {
    image: "../Images/8.jfif",
    title: "Jigsaw Puzzle Wooden Board",
    rating: 1.2,
    price: "849",
    off: "UP TO 29% OFF",
    des: "The jigsaw puzzle board is made with a sleek black finish and a vivid, eye-catching design. It features a magnetic backing with 1/2 thick white foam, which helps with finding the perfect spot to stow away your jigsaw pieces. The bottom of the jigs African-inspired geometric cutouts add a traditional yet modern flair to the design. This jigsaw puzzle board won't take up much room and is perfect for a room in your home. Why spend hours with a jigsaw puzzle when you can spend hours with this puzzle board? The jigsaw puzzle board is made with a sleek black finish and a vivid, eye-catching design. It features a magnetic backing with 1/2 thick white foam, which helps with finding the perfect spot to stow away your jigsaw pieces. The bottom of the jigs African-inspired geometric cutouts add a traditional yet modern flair to the design. This jigsaw puzzle board won't take up much room and is perfect for a room in your home. Why spend hours with a jigsaw puzzle when you can spend hours with this puzzle board?",
  },
  {
    image: "../Images/9.jfif",
    title: "Women Patchwork Elastic Waist Skirt",
    rating: 4.7,
    price: "1699",
    off: "UP TO 23% OFF",
    des: "This is a perfect choice for you! This women p astwork elastic waist skirt with ruffles comes with a free patchwork design for you to get the cool and fashionable skirt you need this season! This skirt has 28 different unique and adorable color combinations to choose from and is made from high-quality materials as well! You're also able to choose from many different length options to get your favorite style from! Feel feminine when wearing this women patchwork elastic waist skirt skirt with its feminine look, the flower design on the front and the ruffles on the waist, plus easy-to-wearing style. This is a perfect choice for you! This women p astwork elastic waist skirt with ruffles comes with a free patchwork design for you to get the cool and fashionable skirt you need this season! This skirt has 28 different unique and adorable color combinations to choose from and is made from high-quality materials as well! You're also able to choose from many different length options to get your favorite style from! Feel feminine when wearing this women patchwork elastic waist skirt skirt with its feminine look, the flower design on the front and the ruffles on the waist, plus easy-to-wearing style.",
  },
  {
    image: "../Images/10.jfif",
    title: "STARKING Steel Watch",
    rating: 3.7,
    price: "4699",
    off: "UP TO 28% OFF",
    des: "You'll always be on the lookout for this watch. It's made of steel, so it's sturdy and timeless. Its matte dial is scratch-resistant so you don't have to worry about ruining the watch with fingerprints. The watch is water resistant and will never fade or turn your wrist yellow with age. You'll also love the fact that it comes in at least 9 different colors. You'll always be on the lookout for this watch. It's made of steel, so it's sturdy and timeless. Its matte dial is scratch-resistant so you don't have to worry about ruining the watch with fingerprints. The watch is water resistant and will never fade or turn your wrist yellow with age. You'll also love the fact that it comes in at least 9 different colors.",
  },
  {
    image: "../Images/11.jfif",
    title: "Zeblaze Thor 5 Dual Smartwatch",
    rating: 4.7,
    price: "14599",
    off: "UP TO 14% OFF",
    des: "Introducing Zeblaze Thor 5 Dual Smartwatch, the brand new product by Zeblaze to control your life. With its built-in GPS chip that can pair up to 5 different devices at the same time, it will be a tough task for any watch to compete with Zeblaze Thor 5 Smartwatch. Thor the guardian of Asgard is ready to assist you in your time of need, if you prepare for the future with this watch. Introducing Zeblaze Thor 5 Dual Smartwatch, the brand new product by Zeblaze to control your life. With its built-in GPS chip that can pair up to 5 different devices at the same time, it will be a tough task for any watch to compete with Zeblaze Thor 5 Smartwatch. Thor the guardian of Asgard is ready to assist you in your time of need, if you prepare for the future with this watch.",
  },
  {
    image: "../Images/12.jfif",
    title: "400ml Mixer juicer",
    rating: 2.4,
    price: "2499",
    off: "UP TO 32% OFF",
    des: "Pouring fruit, vegetables and herbs into a blender is a tedious and fruitless task with a tedious and fruitless task-- until now. You can do it one better with the 400ml mixer juicer. With the highest performance and noiseless operation, the 400ml mixer juicer can help make juices in seconds. For vegetables and fruits, the maxiblender 400ml mixer juicer can extract more juice from these foods than any other blender. Pouring fruit, vegetables and herbs into a blender is a tedious and fruitless task with a tedious and fruitless task-- until now. You can do it one better with the 400ml mixer juicer. With the highest performance and noiseless operation, the 400ml mixer juicer can help make juices in seconds. For vegetables and fruits, the maxiblender 400ml mixer juicer can extract more juice from these foods than any other blender.",
  },
  {
    image: "../Images/13.jfif",
    title: "Handheld Electric Juicer",
    rating: 4.5,
    price: "2399",
    off: "UP TO 33% OFF",
    des: "With the Juicer, you can make exquisite-tasting fruit and vegetable juices at home in a fraction of the time! The juicer is electric, so you can juice in the time it takes to read a cookbook. All it takes is a few seconds to switch on the juicer and watch produce turn into delightful juice with a minimum of effort. A large cutting disc is on the juicer's motor, which means the juicer will create the perfect amount of juice for your nutritional needs Pouring fruit, vegetables and herbs into a blender is a tedious and fruitless task with a tedious and fruitless task-- until now. You can do it one better with the 400ml mixer juicer. With the highest performance and noiseless operation, the 400ml mixer juicer can help make juices in seconds. For vegetables and fruits, the maxiblender 400ml mixer juicer can extract more juice from these foods than any other blender.",
  },
  {
    image: "../Images/14.jfif",
    title: "Women Quartz Wheel Watch",
    rating: 5.0,
    price: "7299",
    off: "UP TO 51% OFF",
    des: "Quartz is the ultimate timekeeping technology because it’s accurate, durable, and environmentally friendly. Quartz technology is inside our watches, allowing you to stay on time without the need for battery replacement. This watch is the ultimate accessory for women, boasting the latest fashion and high quality materials wrapped in a refined design. Slips comfortably under a shirt sleeve, that easily slides and adjusts with a push button clasp. The clasp on this watch is made from stainless-steel and offers a high level of protection Quartz is the ultimate timekeeping technology because it’s accurate, durable, and environmentally friendly. Quartz technology is inside our watches, allowing you to stay on time without the need for battery replacement. This watch is the ultimate accessory for women, boasting the latest fashion and high quality materials wrapped in a refined design. Slips comfortably under a shirt sleeve, that easily slides and adjusts with a push button clasp. The clasp on this watch is made from stainless-steel and offers a high level of protection",
  },
  {
    image: "../Images/15.jfif",
    title: "Causal Ink Print Top Suit",
    rating: 3.8,
    price: "6499",
    off: "UP TO 35% OFF",
    des: "A new modern addition for the summer, the Causal Ink Print Top Suit is the perfect look for the busy professional on the go. Regular fit shirt keeps you cool and dry in the summer or in the office, slimming down to accentuate your torso. The sporty look is perfect paired with causal ink print blazer and polished oxfords or Stan Smiths Tan. Essential, this suit is a must-have for all of your work-ready looks. A new modern addition for the summer, the Causal Ink Print Top Suit is the perfect look for the busy professional on the go. Regular fit shirt keeps you cool and dry in the summer or in the office, slimming down to accentuate your torso. The sporty look is perfect paired with causal ink print blazer and polished oxfords or Stan Smiths Tan. Essential, this suit is a must-have for all of your work-ready looks.",
  },
  {
    image: "../Images/16.jfif",
    title: "Women Relogio Feminino Quartz Watch",
    rating: 1.4,
    price: "1099",
    off: "UP TO 27% OFF",
    des: "Women Relogio Feminino Watch Quarz is a perfect timepiece for women of all ages. It has a feminine design and dressing up the watch can be very easy thanks to its elegant and beautiful strap.\n\nA product by ALFA Luxury Watches, a quality that has been the company’s experience since the beginning of its history.\n\n-Adopting the technology of Swiss quartz watches, which is renowned for its accuracy, precision and durabilityomen Relogio Feminino Watch Quarz is a perfect timepiece for women of all ages. It has a feminine design and dressing up the watch can be very easy thanks to its elegant and beautiful strap.\n\nA product by ALFA Luxury Watches, a quality that has been the company’s experience since the beginning of its history.\n\n-Adopting the technology of Swiss quartz watches, which is renowned for its accuracy, precision and durability",
  },
  {
    image: "../Images/17.jfif",
    title: "Women High Waist Bandage Maxi Skirt",
    rating: 4.6,
    price: "2199",
    off: "UP TO 19% OFF",
    des: "Introducing the newest women's maxi skirt style and performance must-have! The Women High Waist Bandage Maxi Skirt has a high waist band with resilient compression built into the form-fitting fabric to leave strong muscles and smooth skin where it counts most and gives your waist the perfect trim shape. The Women’s High Waist Bandage Maxi Skirt is a fantastic lightweight, breathable style with a flattering, figure-flattering fit and extra volume to complete a Introducing the newest women's maxi skirt style and performance must-have! The Women High Waist Bandage Maxi Skirt has a high waist band with resilient compression built into the form-fitting fabric to leave strong muscles and smooth skin where it counts most and gives your waist the perfect trim shape. The Women’s High Waist Bandage Maxi Skirt is a fantastic lightweight, breathable style with a flattering, figure-flattering fit and extra volume to complete a",
  },
  {
    image: "../Images/18.jfif",
    title: "Bluetooth Stereo Earphone",
    rating: 3.6,
    price: "3199",
    off: "UP TO 29% OFF",
    des: "Reduce the clutter by sporting these stylish headphones with a state of the art advanced wireless Bluetooth 4.0 meets A2DP stereo wireless connection. The wireless headset has one built in microphone for wireless calling and one wireless earbud earpiece so that you can listen privately. The earbud headphone has a single button that allows the Bluetooth function and the volume. For music enjoyment and convenience this type is a great companion. Reduce the clutter by sporting these stylish headphones with a state of the art advanced wireless Bluetooth 4.0 meets A2DP stereo wireless connection. The wireless headset has one built in microphone for wireless calling and one wireless earbud earpiece so that you can listen privately. The earbud headphone has a single button that allows the Bluetooth function and the volume. For music enjoyment and convenience this type is a great companion.",
  },
  {
    image: "../Images/19.jfif",
    title: "Womens Stainless Steel Bracelet Watch",
    rating: 4.7,
    price: "1549",
    off: "UP TO 26% OFF",
    des: "2016 new fashion style cool business women stainless steel watch, simple structure and exquisite jewelry is ideal for all types of occasions, such as meetings, walks, workouts, school and more. Eco-friendly, healthy and stylish, the Women’s Stainless Steel Creative watches is a perfect addition to your everyday look. 2016 new fashion style cool business women stainless steel watch, simple structure and exquisite jewelry is ideal for all types of occasions, such as meetings, walks, workouts, school and more. Eco-friendly, healthy and stylish, the Women’s Stainless Steel Creative watches is a perfect addition to your everyday look.",
  },
  {
    image: "../Images/20.jfif",
    title: "Zealot H1 Sport Bluetooth",
    rating: 4.2,
    price: "3299",
    off: "UP TO 34% OFF",
    des: "Promote mental clarity with this elegant and durable watch, designed with many features for versatility and timeless style. The anti-absorption for the watch band is recommended for everyday use; features a gently arched bezel along with an easy to read, bright and clear dial allows everyone to check the time. Reduce the clutter by sporting these stylish headphones with a state of the art advanced wireless Bluetooth 4.0 meets A2DP stereo wireless connection. The wireless headset has one built in microphone for wireless calling and one wireless earbud earpiece so that you can listen privately. The earbud headphone has a single button that allows the Bluetooth function and the volume. For music enjoyment and convenience this type is a great companion.",
  },
  {
    image: "../Images/21.jfif",
    title: "800W Electric Mixer",
    rating: 3.8,
    price: "6999",
    off: "UP TO 13% OFF",
    des: "What do you do when you need a mixer and don’t have one? Heirloom’s industrial-strength kitchen mixer whips up standard, large and jumbo batches of dough with ease. Your kitchen is about to takeover with joy with this smart and power packed appliance that can share the load of your batter bowl and heavy cocktail glasses. What do you do when you need a mixer and don’t have one? Heirloom’s industrial-strength kitchen mixer whips up standard, large and jumbo batches of dough with ease. Your kitchen is about to takeover with joy with this smart and power packed appliance that can share the load of your batter bowl and heavy cocktail glasses.",
  },
  {
    image: "../Images/22.jfif",
    title: "Mini Fruit Squeezer",
    rating: 2.9,
    price: "2099",
    off: "UP TO 24% OFF",
    des: "It’s easy to squeeze fresh, colorful fruit juice into your favorite glass. Simply twist the base of the fruit squeezer to tell it to stop squeezing and it begins the process of removing the juice from the soft flesh of any fruit or veggie you put inside. For peeling fruit, it's the fastest, most efficient way to get the desired amount of fruit without having to peel, slice, and separate, giving you more time for cooking, eating, and drinking your delicious masterpiece. It’s easy to squeeze fresh, colorful fruit juice into your favorite glass. Simply twist the base of the fruit squeezer to tell it to stop squeezing and it begins the process of removing the juice from the soft flesh of any fruit or veggie you put inside. For peeling fruit, it's the fastest, most efficient way to get the desired amount of fruit without having to peel, slice, and separate, giving you more time for cooking, eating, and drinking your delicious masterpiece.",
  },
  {
    image: "../Images/23.jfif",
    title: "LEMFO LEMD Smart Watch",
    rating: 4.2,
    price: "8999",
    off: "UP TO 36% OFF",
    des: "Promising to revolutionize the way we experience time, the LEMFO LEMD Smart Watch is a unique timepiece that lets you live in the moment and brighten any day. The LEMFO LEMD Smart Watch uses a semi-transparent display that houses dynamic, circular LEDs which change colors accordingly - to tell you the weather or provide you with a simple alert. Studies also show that LEMFO LEMD Smart Watches are more likely to produce a positive mood and Promising to revolutionize the way we experience time, the LEMFO LEMD Smart Watch is a unique timepiece that lets you live in the moment and brighten any day. The LEMFO LEMD Smart Watch uses a semi-transparent display that houses dynamic, circular LEDs which change colors accordingly - to tell you the weather or provide you with a simple alert. Studies also show that LEMFO LEMD Smart Watches are more likely to produce a positive mood and",
  },
  {
    image: "../Images/24.jfif",
    title: "Summer Casual Small Feet Pants",
    rating: 4.3,
    price: "2999",
    off: "UP TO 50% OFF",
    des: "Shop the latest addition to our Summer Casual line-- The Summer Casual Small Feet Pants! These shorts feature a gathered waist and leg, soft and breathable fabric, and a rear length to allow for easy movement when busy at the pool or beach. Pair the exclusive new colors, including pink, black, and beige, with these standout prints and finishes for a kiddie fashion-forward look that’ll have you looking blast from the past. Shop the latest addition to our Summer Casual line-- The Summer Casual Small Feet Pants! These shorts feature a gathered waist and leg, soft and breathable fabric, and a rear length to allow for easy movement when busy at the pool or beach. Pair the exclusive new colors, including pink, black, and beige, with these standout prints and finishes for a kiddie fashion-forward look that’ll have you looking blast from the past.",
  },
  {
    image: "../Images/25.jfif",
    title: "PUBG Mobile Gamepad Grip With Joystick Trigger",
    rating: 4.1,
    price: "899",
    off: "UP TO 31% OFF",
    des: "Gamepad designed for PUBG Mobile is designed to keep your hands print off the screen, ensure a comfortable game-play experience, and maximize your shooting accuracy.An excellent accessory for your game.\n-Experience your game in comfort by keeping your hands off the screen to eliminate double input lag.\n-Customized for optimum shooting performance and accuracy with a trigger for greater accuracy. Gamepad designed for PUBG Mobile is designed to keep your hands print off the screen, ensure a comfortable game-play experience, and maximize your shooting accuracy.An excellent accessory for your game.\n-Experience your game in comfort by keeping your hands off the screen to eliminate double input lag.\n-Customized for optimum shooting performance and accuracy with a trigger for greater accuracy.",
  },
  {
    image: "../Images/26.jfif",
    title: "Fitness Equipment Slimming Belt",
    rating: 3.6,
    price: "799",
    off: "UP TO 27% OFF",
    des: "This is a great product for the ambitious! No one wants to feel like they're too much of a fatty, but this belt can help you slim down easily! It is a body belt that contains a vacuum suction vacuum tube! It is soft and easy to wear just like other belts. It is also perfect for women who have long and taut muscles. This is a great product for the ambitious! No one wants to feel like they're too much of a fatty, but this belt can help you slim down easily! It is a body belt that contains a vacuum suction vacuum tube! It is soft and easy to wear just like other belts. It is also perfect for women who have long and taut muscles.",
  },
  {
    image: "../Images/27.jfif",
    title: "Women Chiffon Floral Print Maxi Skirt",
    rating: 2.7,
    price: "1499",
    off: "UP TO 25% OFF",
    des: "Whether it is a casual day out with girlfriends or a girl's night out with the girls, this summer top and skirt is perfect for any occasion! Made in a polyester acetate and polyester chiffon bi-color fabric, this maxi skirt features an asymmetric front and is lined with a cotton lining. The print features blooming flowers and leaves, shown to the side with a light green and jade print. The top has a cool, metallic look and can be tightened at Whether it is a casual day out with girlfriends or a girl's night out with the girls, this summer top and skirt is perfect for any occasion! Made in a polyester acetate and polyester chiffon bi-color fabric, this maxi skirt features an asymmetric front and is lined with a cotton lining. The print features blooming flowers and leaves, shown to the side with a light green and jade print. The top has a cool, metallic look and can be tightened at",
  },
  {
    image: "../Images/28.jfif",
    title: "T9 Wireless Bluetooth",
    rating: 4.1,
    price: "1899",
    off: "UP TO 30% OFF",
    des: "Our Wireless BT6 Bluetooth Central Hub uses the newest Bluetooth 4.0 technology to connect products with other Bluetooth enabled devices anywhere in your home. Bluetooth technology is the reason this device is so convenient. Our custom contoured design allows it to blend in with your home decor and wireless connection range is up to 100'. T9 wireless Bluetooth universal remote control allows you to control all of your devices at once. Our Wireless BT6 Bluetooth Central Hub uses the newest Bluetooth 4.0 technology to connect products with other Bluetooth enabled devices anywhere in your home. Bluetooth technology is the reason this device is so convenient. Our custom contoured design allows it to blend in with your home decor and wireless connection range is up to 100'. T9 wireless Bluetooth universal remote control allows you to control all of your devices at once.",
  },
  {
    image: "../Images/29.jfif",
    title: "Analog Quartz Watch",
    rating: 4.4,
    price: "899",
    off: "UP TO 31% OFF",
    des: "Featuring a matte plastic case and elegant timepiece, the Analog Quartz Watch is both subtly distinguished and durable. With its classic design that is crafted from a combination of materials--such as stainless steel, leather and matte plastic--this watch will last for many years. Featuring a matte plastic case and elegant timepiece, the Analog Quartz Watch is both subtly distinguished and durable. With its classic design that is crafted from a combination of materials--such as stainless steel, leather and matte plastic--this watch will last for many years. Featuring a matte plastic case and elegant timepiece, the Analog Quartz Watch is both subtly distinguished and durable. With its classic design that is crafted from a combination of materials--such as stainless steel, leather and matte plastic--this watch will last for many years.",
  },
  {
    image: "../Images/30.jfif",
    title: "Wireless Stereo Headset",
    rating: 3.3,
    price: "1199",
    off: "UP TO 33% OFF",
    des: "The Wireless Stereo Headset is your perfect companion for your outdoor adventures. This compact and noise-cancelling headset gives you a great experience across three modes: wireless home headset, wireless handheld headset, and wireless Bluetooth headset. The Wireless Stereo Headset is your perfect companion for your outdoor adventures. This compact and noise-cancelling headset gives you a great experience across three modes: wireless home headset, wireless handheld headset, and wireless Bluetooth headset.",
  },
  {
    image: "../Images/31.jfif",
    title: "Smart Display Water Bottle",
    rating: 4.5,
    price: "3499",
    off: "UP TO 36% OFF",
    des: "Lightweight and simple, the Smart Display Water Bottle is easy to carry around, and it keeps track of water consumption in a unique way. It includes a Bluetooth enabled sensor that can connect up to your phone to keep track of relevant data - the number of days you drink water, track your hydration, and gamify your drinking. It also comes with a free 1-year subscription to remote monitoring service MyHydro, which allows you to trace your water consumption on a map, watch animated stats Lightweight and simple, the Smart Display Water Bottle is easy to carry around, and it keeps track of water consumption in a unique way. It includes a Bluetooth enabled sensor that can connect up to your phone to keep track of relevant data - the number of days you drink water, track your hydration, and gamify your drinking. It also comes with a free 1-year subscription to remote monitoring service MyHydro, which allows you to trace your water consumption on a map, watch animated stats",
  },
  {
    image: "../Images/32.jfif",
    title: "Mini Fruit Squeezer",
    rating: 4.6,
    price: "1499",
    off: "UP TO 25% OFF",
    des: "It’s essential to avoid wasting fruits which are in season, and that’s where the Mini Fruit Squeezer comes in! This stylish gadget easily squeezes out the fresh juice and fibrous parts that you won’t want in your drink. The squeezer is small enough to fit in the palm of your hand, saving you space in your fridge and bringing you convenience in your cooking. It’s essential to avoid wasting fruits which are in season, and that’s where the Mini Fruit Squeezer comes in! This stylish gadget easily squeezes out the fresh juice and fibrous parts that you won’t want in your drink. The squeezer is small enough to fit in the palm of your hand, saving you space in your fridge and bringing you convenience in your cooking.",
  },
  {
    image: "../Images/33.jfif",
    title: "Donut Shape Rainbow Backpack",
    rating: 3.7,
    price: "3499",
    off: "UP TO 53% OFF",
    des: "A multi-purpose pack, with a zipper inside, which enables you to carry an extra jacket and hoodie as well as skip rope, balls, a towel and other necessary items. The backpack has a large pocket at the back that can store a lot of light items and a mesh pocket at the front to keep your water or other items from dropping to the ground. The backpack is lightweight and comfortable to wear. A multi-purpose pack, with a zipper inside, which enables you to carry an extra jacket and hoodie as well as skip rope, balls, a towel and other necessary items. The backpack has a large pocket at the back that can store a lot of light items and a mesh pocket at the front to keep your water or other items from dropping to the ground. The backpack is lightweight and comfortable to wear.",
  },
  {
    image: "../Images/34.jfif",
    title: "Summer Silk and Linen Top Suit",
    rating: 4.2,
    price: "2099",
    off: "UP TO 50% OFF",
    des: "This linen top suit is the perfect relationship of luxury and casual elegance. With a 100% linen suit available in a range of solid colors, you'll get an easy, relaxed feel without sacrificing style. This summer staple will be the first thing on your shopping list to update your summer wardrobe. This linen top suit is the perfect relationship of luxury and casual elegance. With a 100% linen suit available in a range of solid colors, you'll get an easy, relaxed feel without sacrificing style. This summer staple will be the first thing on your shopping list to update your summer wardrobe.",
  },
  {
    image: "../Images/35.jfif",
    title: "Wooden Tree ball Puzzles Game",
    rating: 3.7,
    price: "899",
    off: "UP TO 31% OFF",
    des: "The Wooden Tree ball puzzles game is a great game of skill. It tests your coordination, concentration and ability to solve puzzles. It is a nice game to play with family and friends. The game includes: 1 ball, 10 painted wooden balls and 3 pictures with 10 pieces of puzzles. The Wooden Tree ball puzzles game is a great game of skill. It tests your coordination, concentration and ability to solve puzzles. It is a nice game to play with family and friends. The game includes: 1 ball, 10 painted wooden balls and 3 pictures with 10 pieces of puzzles.",
  },
  {
    image: "../Images/36.jfif",
    title: "Women Stainless Steel Creative Quartz Watch",
    rating: 4.4,
    price: "2499",
    off: "UP TO 31% OFF",
    des: "2016 new fashion style cool business women stainless steel watch, simple structure and exquisite jewelry is ideal for all types of occasions, such as meetings, walks, workouts, school and more. Eco-friendly, healthy and stylish, the Women’s Stainless Steel Creative watches is a perfect addition to your everyday look. 2016 new fashion style cool business women stainless steel watch, simple structure and exquisite jewelry is ideal for all types of occasions, such as meetings, walks, workouts, school and more. Eco-friendly, healthy and stylish, the Women’s Stainless Steel Creative watches is a perfect addition to your everyday look.",
  },
  {
    image: "../Images/37.jfif",
    title: "Women Loose Cotton Casual Skirt",
    rating: 1.4,
    price: "1099",
    off: "UP TO 27% OFF",
    des: "【In the style of casual models】All the more, the upper part is long enough to work!, Relaxed and comfortable loose cotton casual skir featuring side pockets and an elastic waist., The material is comfortable and it has a good thumb-lift of the waist. 【In the style of casual models】All the more, the upper part is long enough to work!, Relaxed and comfortable loose cotton casual skir featuring side pockets and an elastic waist., The material is comfortable and it has a good thumb-lift of the waist.",
  },
  {
    image: "../Images/38.jfif",
    title: "Mini Wireless Earphones",
    rating: 4.9,
    price: "2799",
    off: "UP TO 35% OFF",
    des: "Enjoy your favorite tunes in earbuds that are as lightweight as they are stylish. These sleek wireless headphones come in five vibrant colors, each designed with a different shade of fabric that wraps around the earbud. They’re impressively small, but don’t sacrifice the sound quality with these lightweight earbuds. Enjoy your favorite tunes in earbuds that are as lightweight as they are stylish. These sleek wireless headphones come in five vibrant colors, each designed with a different shade of fabric that wraps around the earbud. They’re impressively small, but don’t sacrifice the sound quality with these lightweight earbuds.",
  },
  {
    image: "../Images/39.jfif",
    title: "Analog Casual Watch",
    rating: 4.4,
    price: "2499",
    off: "UP TO 32% OFF",
    des: "This watch is great for those looking for a simple watch with a slim, sleek look that suits any occasion. The smooth band is made from stainless steel and it is adjustable.\nFeatures: Adhesive band design for easy on and off. The watch is lightweight for an all day comfort. Silicone adjustment strap for easy length adjustment. This watch is great for those looking for a simple watch with a slim, sleek look that suits any occasion. The smooth band is made from stainless steel and it is adjustable.\nFeatures: Adhesive band design for easy on and off. The watch is lightweight for an all day comfort. Silicone adjustment strap for easy length adjustment.",
  },
  {
    image: "../Images/40.jfif",
    title: "Sport Bluetooth Earphone",
    rating: 1.9,
    price: "2199",
    off: "UP TO 23% OFF",
    des: "Whether exercising, running, or even sleeping, listen to music without uncomfortable wires. The adaptive sound transmission allows the earphone to be comfortable and secure. It has a built-in interactive signaling system designed to be compatible with all phones. With a 15 hour battery life, it's the perfect workout companion. Whether exercising, running, or even sleeping, listen to music without uncomfortable wires. The adaptive sound transmission allows the earphone to be comfortable and secure. It has a built-in interactive signaling system designed to be compatible with all phones. With a 15 hour battery life, it's the perfect workout companion.",
  },
  {
    image: "../Images/41.jfif",
    title: "Honor Pro 5.0 Earphone",
    rating: 4.3,
    price: "6499",
    off: "UP TO 28% OFF",
    des: "The Honor Pro 5.0 Earphone is designed to be in-ear- well under ear, so they are not in your line of sight. They also have a proprietary “true noise isolation” technology that reduces outside noise to minimize distraction. The cable is tangle-resistant and it comes with a carrying pouch, so now you don’t have to worry about your earphones getting tangled and falling out while you’re on the bus. The Honor Pro 5.0 Earphone is designed to be in-ear- well under ear, so they are not in your line of sight. They also have a proprietary “true noise isolation” technology that reduces outside noise to minimize distraction. The cable is tangle-resistant and it comes with a carrying pouch, so now you don’t have to worry about your earphones getting tangled and falling out while you’re on the bus.",
  },
  {
    image: "../Images/42.jfif",
    title: "Electric Food Kettle",
    rating: 3.0,
    price: "2899",
    off: "UP TO 28% OFF",
    des: "The Minute Chef Electric Food Kettle is the most powerful electric food kettle in the world, with a boil time of only 60 seconds! Boil enough water for five people's worth of food in a fraction of the time. Save time when boiling water for your favorite dish with this electric food kettle. It is easy to operate and features a simple design, with a water reservoir that is easy to fill. The Minute Chef Electric Food Kettle is the most powerful electric food kettle in the world, with a boil time of only 60 seconds! Boil enough water for five people's worth of food in a fraction of the time. Save time when boiling water for your favorite dish with this electric food kettle. It is easy to operate and features a simple design, with a water reservoir that is easy to fill.",
  },
];

if (localStorage.getItem("productInfo") == null) {
  localStorage.setItem("productInfo", JSON.stringify([]));
}


var filteredData = JSON.parse(JSON.stringify(productData));
document.querySelector('#sortInput').addEventListener('change', function () {
  var sortType = document.querySelector('#sortInput').value;
  if (sortType === 'none') {
    displayAllProducts(productData);
  } else {
    filteredData.sort(function (a, b) {
      if (sortType === 'popularity') {
        return b.rating - a.rating;
      } else if (sortType === 'lowToHigh') {
        return a.price - b.price;
      } else {
        return b.price - a.price;
      }

    });
    displayAllProducts(filteredData);
  }
});





function displayAllProducts(product) {
  document.querySelector('#allProducts').innerHTML = '';

  var allProductsDiv = document.getElementById("allProducts");
  // allProductsDiv.innerHTML = null;
  product.forEach(function (ele) {
    var mainDiv = document.createElement("div");
    mainDiv.id = "productLayout";
    let prodCon = document.createElement("div")

    let div1 = document.createElement("div");
    div1.id = "imageBox";

    let imgInfo = document.createElement("a");
    imgInfo.href = "../HTML/productInfo.html";
    let div1img = document.createElement("img");
    div1img.src = ele.image;
    imgInfo.appendChild(div1img);

    div1.appendChild(imgInfo);

    let div2 = document.createElement("div");
    div2.id = "titleBox";
    let div2title = document.createElement("p");
    div2title.innerHTML = ele.title;
    div2.appendChild(div2title);
    let div2rating = document.createElement("div");
    div2rating.id = "ratingBox";
    let div2point = document.createElement("span");
    div2point.innerHTML = ele.rating + "/5";
    let div2star = document.createElement("span");
    div2star.className = "fa fa-star checked";
    // div2star.innerHTML = &ensp;
    div2rating.appendChild(div2point);
    div2rating.appendChild(div2star);
    div2.appendChild(div2rating);
    // div2.appendChild(div2star);

    let div3 = document.createElement("div");
    div3.id = "priceBox";
    let div3price = document.createElement("p");
    div3price.innerHTML = "₹" + ele.price;
    let div3off = document.createElement("p");
    div3off.innerHTML = ele.off;
    div3.appendChild(div3price);
    div3.appendChild(div3off);




    prodCon.appendChild(div1);
    prodCon.appendChild(div2);
    prodCon.appendChild(div3);
    mainDiv.appendChild(prodCon)

    div1.onclick = function () {
      localStorage.setItem("productInfo", JSON.stringify(ele));
    };

    allProductsDiv.appendChild(mainDiv);
  });
}
displayAllProducts(productData);

function filterLessthan1000(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.price <= 1000) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}

function filterLessthan3000(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.price <= 3000) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}

function filterLessthan5000(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.price <= 5000) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}

function filterLessthan10000(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.price <= 10000) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}

document.querySelector('#filterInputP').addEventListener('change', function () {
  var sortType = document.querySelector('#filterInputP').value;
  if (sortType === 'none') {
    filterMore4(productData);
  } else if (sortType === 'less1000') {
    var data = filterLessthan1000(productData);
    displayAllProducts(data);
  } else if (sortType === 'less3000') {
    var data = filterLessthan3000(productData);
    displayAllProducts(data);
  } else if (sortType === 'less5000') {
    var data = filterLessthan5000(productData);
    displayAllProducts(data);
  } else if (sortType === 'less10000') {
    var data = filterLessthan10000(productData);
    displayAllProducts(data);
  }
});

function filterMore4(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.rating >= 4) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}
function filterMore3(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.rating >= 3) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}
function filterMore2(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.rating >= 2) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}
function filterMore1(productData) {
  var newData = productData.filter(function (prdoductItem) {
    if (prdoductItem.rating >= 1) {
      return true;
    } else {
      return false;
    }
  });
  return newData;
}

document.querySelector('#filterInputR').addEventListener('change', function () {
  var sortType = document.querySelector('#filterInputR').value;
  if (sortType === 'none') {
    displayAllProducts(productData);
  } else if (sortType === '4star') {
    var data = filterMore4(productData);
    displayAllProducts(data);
  } else if (sortType === '3star') {
    var data = filterMore3(productData);
    displayAllProducts(data);
  } else if (sortType === '2star') {
    var data = filterMore2(productData);
    displayAllProducts(data);
  } else if (sortType === '1star') {
    var data = filterMore1(productData);
    displayAllProducts(data);
  }
});




var subcategories = [
  "Keyboards & Mouse",
  "Home Improvement",
  "Bluetooth Earphone",
  "Sporting Bluetooth",
  "Wireless Chargers",
  "Wireless Speakers",
  "School Backpacks",
  "Fitness Merchandise",
  "Home Decor",
  "Kid's Shoes",
  "Makeup Accessories",
  "Wired Headphones",
  "Smart Watches",
  "Men's Watches",
  "Electronics",
  "Wall Art",
  "Laptops",
  "Mobiles Accessories",
  "Power Banks",
  "Apple Accessories",
];

function displaySubcategories(sub) {
  var allCatDiv = document.getElementById("subCat");
  sub.forEach(function (ele) {
    let catDiv = document.createElement("p");
    catDiv.id = "catId";
    catDiv.innerHTML = ele;
    allCatDiv.appendChild(catDiv);
  });
}

displaySubcategories(subcategories);

var cartCount = document.getElementById("count")
function counts() {
  var a = JSON.parse(localStorage.getItem("addToCart"))

  cartCount.innerText = a.length
}
counts()


